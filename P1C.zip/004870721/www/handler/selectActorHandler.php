<?php
require 'DataRequest.php';

$dataRequest = new DataRequest();
echo $dataRequest->SelectTop20LatestActorAdded();


?>