This calculator is built using JetBrains in mac OSX.

